package com.jaayakjend.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    TextView todaySales, status;

    String money(long n) {
        return NumberFormat.getNumberInstance(Locale.FRANCE).format(n) + " FCFA";
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db = new DB(this);

        todaySales = findViewById(R.id.todaySales);
        status = findViewById(R.id.status);

        findViewById(R.id.btnSale).setOnClickListener(v -> saleDialog());
        findViewById(R.id.btnProducts).setOnClickListener(v -> productDialog());
        findViewById(R.id.btnClients).setOnClickListener(v -> clientDialog());
        findViewById(R.id.btnHistory).setOnClickListener(v -> historyDialog());
        findViewById(R.id.btnBilan).setOnClickListener(v -> bilanDialog());
        refresh();
    }

    void refresh() {
        todaySales.setText("Vente bi tey : " + money(db.totalSales()));
        status.setText("Base de données locale : active • " + db.countProducts() + " produits • " + db.countSales() + " ventes");
    }

    void productDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText name = field("Turu produit");
        EditText buy = field("Prix jënd");
        EditText sell = field("Prix jaay");
        EditText qty = field("Nombre");
        box.addView(name); box.addView(buy); box.addView(sell); box.addView(qty);
        new android.app.AlertDialog.Builder(this).setTitle("Yokk Produit").setView(box)
            .setPositiveButton("Denc Produit", (d,w) -> {
                db.addProduct(name.getText().toString(), val(buy), val(sell), (int)val(qty));
                refresh();
            }).setNegativeButton("Annuler", null).show();
    }

    void saleDialog() {
        final String[] names = db.productNames();
        if (names.length == 0) { toast("Ajoute d'abord un produit."); return; }
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        EditText qty = field("Nombre");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.addView(sp); box.addView(qty);
        new android.app.AlertDialog.Builder(this).setTitle("🛒 Jaay").setView(box)
            .setPositiveButton("Dëgël Njaay mi", (d,w) -> {
                int index = sp.getSelectedItemPosition();
                long q = val(qty);
                if(q < 1) q = 1;
                if(db.sell(index, (int)q)) { toast("Njaay bi am na!"); refresh(); }
                else toast("Stock insuffisant.");
            }).setNegativeButton("Annuler", null).show();
    }

    void clientDialog() {
        EditText name = field("Turu client");
        EditText phone = field("Téléphone");
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.addView(name); box.addView(phone);
        new android.app.AlertDialog.Builder(this).setTitle("👥 Yokk Client").setView(box)
            .setPositiveButton("Denc Client", (d,w) -> { db.addClient(name.getText().toString(), phone.getText().toString()); refresh(); })
            .setNegativeButton("Annuler", null).show();
    }

    void historyDialog() {
        new android.app.AlertDialog.Builder(this).setTitle("🧾 Historique des ventes")
            .setMessage(db.history()).setPositiveButton("OK", null).show();
    }

    void bilanDialog() {
        new android.app.AlertDialog.Builder(this).setTitle("📊 Bilan")
            .setMessage("Vente : " + money(db.totalSales()) +
                        "\nProfit : " + money(db.totalProfit()) +
                        "\nNombre de ventes : " + db.countSales() +
                        "\nDettes clients : " + money(db.totalDebt()))
            .setPositiveButton("OK", null).show();
    }

    EditText field(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setPadding(12,12,12,12); return e; }
    long val(EditText e) { try { return Long.parseLong(e.getText().toString().trim()); } catch(Exception x){ return 0; } }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
