package com.jaayakjend.app;

import android.content.*;
import android.database.sqlite.*;
import java.text.NumberFormat;
import java.util.*;
import java.util.Locale;

public class DB extends SQLiteOpenHelper {
    static final String NAME="jaay_ak_jend.db";
    DB(Context c){super(c,NAME,null,1);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,buy INTEGER,sell INTEGER,stock INTEGER)");
        d.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,debt INTEGER DEFAULT 0)");
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product TEXT,qty INTEGER,amount INTEGER,profit INTEGER,created INTEGER)");
    }
    public void onUpgrade(SQLiteDatabase d,int a,int b){}
    long money(String s){try{return Long.parseLong(s);}catch(Exception e){return 0;}}
    void addProduct(String n,long buy,long sell,int q){
        getWritableDatabase().execSQL("INSERT INTO products(name,buy,sell,stock) VALUES(?,?,?,?)",new Object[]{n,buy,sell,q});
    }
    void addClient(String n,String p){
        getWritableDatabase().execSQL("INSERT INTO clients(name,phone,debt) VALUES(?,?,0)",new Object[]{n,p});
    }
    String[] productNames(){
        ArrayList<String> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT name FROM products ORDER BY name",null);
        while(c.moveToNext())a.add(c.getString(0)); c.close();
        return a.toArray(new String[0]);
    }
    boolean sell(int index,int q){
        Cursor c=getReadableDatabase().rawQuery("SELECT id,name,buy,sell,stock FROM products ORDER BY name LIMIT 1 OFFSET "+index,null);
        if(!c.moveToFirst()){c.close();return false;}
        int id=c.getInt(0);String n=c.getString(1);long buy=c.getLong(2),sell=c.getLong(3);int stock=c.getInt(4);c.close();
        if(q>stock)return false;
        SQLiteDatabase d=getWritableDatabase();
        d.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{q,id});
        d.execSQL("INSERT INTO sales(product,qty,amount,profit,created) VALUES(?,?,?,?,?)",
            new Object[]{n,q,sell*q,(sell-buy)*q,System.currentTimeMillis()});
        return true;
    }
    long totalSales(){return sum("SELECT COALESCE(SUM(amount),0) FROM sales");}
    long totalProfit(){return sum("SELECT COALESCE(SUM(profit),0) FROM sales");}
    long totalDebt(){return sum("SELECT COALESCE(SUM(debt),0) FROM clients");}
    int countSales(){return (int)sum("SELECT COUNT(*) FROM sales");}
    int countProducts(){return (int)sum("SELECT COUNT(*) FROM products");}
    long sum(String q){Cursor c=getReadableDatabase().rawQuery(q,null);long x=0;if(c.moveToFirst())x=c.getLong(0);c.close();return x;}
    String history(){
        Cursor c=getReadableDatabase().rawQuery("SELECT product,qty,amount,profit,created FROM sales ORDER BY id DESC LIMIT 30",null);
        StringBuilder s=new StringBuilder();
        NumberFormat f=NumberFormat.getNumberInstance(Locale.FRANCE);
        while(c.moveToNext()){
            s.append("• ").append(c.getString(0)).append(" × ").append(c.getInt(1))
             .append(" — ").append(f.format(c.getLong(2))).append(" FCFA")
             .append(" — Profit ").append(f.format(c.getLong(3))).append(" FCFA\n");
        }
        c.close();
        return s.length()==0?"Aucune vente enregistrée.":s.toString();
    }
}
